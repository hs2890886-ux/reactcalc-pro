# ReactCalc Pro

A responsive calculator starter for mobile and desktop browsers.

## Run
Open `index.html` in a browser, or host it as a static website. No build step or API keys required.

## Features
- Basic arithmetic, decimals, sign toggle and percent
- Clear and delete
- Copy result and keyboard support
- Responsive mobile-friendly layout

This is a replacement starter, not a recovered copy of the original Replit project.
